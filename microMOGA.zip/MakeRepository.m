function Rep=MakeRepository(pop, Rep, F, nRep)        
  
    Temp_Rep=[];
                                       
    Temp_Rep=pop(F);                
    
    delIndex=[];
    for i=1:numel(Rep)
        for j=1:numel(Temp_Rep)
            if(all(Rep(i).Cost==Temp_Rep(j).Cost))
                delIndex=[delIndex
                            j];
            end
        end
    end
    Temp_Rep(delIndex)=[];
    
    Temp_Rep=[Temp_Rep
        Rep];
    
    for i=1:numel(Temp_Rep)
        Temp_Rep(i).IsDominated=false;
    end
    Costs=[Temp_Rep.Cost];
    for i=1:numel(Temp_Rep)
        y=Temp_Rep(i).Cost;
        if numel(Temp_Rep)<2
            break;
        end        
        res=find(all(Costs<=y) & any(Costs<y));
        if ~isempty(res)
            Temp_Rep(i).IsDominated=true;
        end        
        
    end
    if numel(Temp_Rep)>2
        Rep=Temp_Rep(~[Temp_Rep.IsDominated]);   
    else
        Rep=Temp_Rep;
    end
    
    Rep=CalcCrowdingDistance(Rep);
    if numel(Rep)>nRep        
        DelSize=size(Rep,1)-nRep;
        cds = [Rep.CrowdingDistance];
        P=exp(cds/sum(cds));
        P=P/sum(P); 
        sel=[];
        while numel(sel)~=DelSize
            [~,index]=min(cds);
            sel=[sel index];
            cds(index)=1000;                
        end
        Rep(sel,:)=[];

    end            

end