function flag = SimilarityCheck( Rep, PrevRep )
    
    RepCosts=[Rep.Cost];
    delIndex=[];
    
    for i=1:numel(PrevRep)
        for j=1:numel(Rep)
            if(all(PrevRep(i).Cost==Rep(j).Cost))
                delIndex=[delIndex
                            j];
            end
        end
    end
    Rep(delIndex)=[];
    if numel(Rep)>=1
       flag=1;
    else
        flag=0;
    end

end

