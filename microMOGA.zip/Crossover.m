
function [y1 y2]=Crossover(x1,x2,VarMin, VarMax, nVar)

    beta = zeros(1,nVar);
    mu   = rand(1,nVar);
    [proC,disC,proM,disM] = deal(1,20,1,20);
    beta(mu<=0.5) = (2*mu(mu<=0.5)).^(1/(disC+1));
    beta(mu>0.5)  = (2-2*mu(mu>0.5)).^(-1/(disC+1));
    beta = beta.*(-1).^randi([0,1],1,nVar);
    beta(rand(1,nVar)<0.5) = 1;
    beta(repmat(rand(1,1)>proC,1,nVar)) = 1;
    Offspring = [(x1+x2)/2+beta.*(x2-x1)/2
                 (x1+x2)/2-beta.*(x2-x1)/2];
    y1=Offspring(1,:);
    y1 = max(y1, VarMin);
    y1 = min(y1, VarMax);
    y2=Offspring(2,:);
    y2 = max(y2, VarMin);
    y2 = min(y2, VarMax);
end