function pop=CalcCrowdingDistance2(pop,F)

    for k=1:numel(F)
        
%         C=[pop(F{k}).Cost];
%         
%         nObj=size(C,1);
%         
%         nFk=numel(F{k});
%         
%         D=zeros(nFk,nObj);
%         
%         for j=1:nObj
%             
%             Cj=C(j,:);
%             
%             [SortedCj SortOrder]=sort(Cj);
%             
%             D(SortOrder(1),j)=inf;
%             D(SortOrder(end),j)=inf;
%             
%             Cjmin=SortedCj(1);
%             Cjmax=SortedCj(end);
% 
%             for i=2:nFk-1 
%                 if Cjmin ~= Cjmax 
%                     D(SortOrder(i),j)=(SortedCj(i+1)-SortedCj(i-1))/(Cjmax-Cjmin);
%                 elseif isinf(Cjmin) || isinf(Cjmax) || isnan(Cjmin) || isnan(Cjmax)
%                     D(SortOrder(i),j)=0;
%                 else
%                     D(SortOrder(i),j)=(SortedCj(i+1)-SortedCj(i-1));
%                 end
%             end
%             
%         end
%         
%         for i=1:nFk
%             pop(F{k}(i)).CrowdingDistance=sum(D(i,:));
%         end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        CrowdDis = zeros(1,numel(F{k}));
        if numel(F{k})>=2
            costs=[pop(F{k}).Cost]';
            Fmax = max(costs,[],1);
            Fmin = min(costs,[],1);
            for i=1:size(costs,2)
               [~,rank] = sortrows(costs(:,i));
                CrowdDis(rank(1))   = inf;
                CrowdDis(rank(end)) = inf; 
                for j = 2 : size(costs,1)-1
                    if (Fmax(i)-Fmin(i))>0
                        CrowdDis(rank(j)) = CrowdDis(rank(j))+(costs(rank(j+1),i)-costs(rank(j-1),i))/(Fmax(i)-Fmin(i));
                    else
                        CrowdDis(rank(j)) = CrowdDis(rank(j))+(costs(rank(j+1),i)-costs(rank(j-1),i));
                    end
                end
            end
            for j = 1 : size(costs,1)
                pop(F{k}(j)).CrowdingDistance=CrowdDis(j);
            end
        elseif numel(F{k})==1
            pop(F{k}(1)).CrowdingDistance=inf;
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    end

end