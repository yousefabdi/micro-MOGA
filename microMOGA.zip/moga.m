%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%  Micro Multi-objective Genetic Algorithm
%%%%%%%%%%%  Programmed By: Yousef Abdi
%%%%%%%%%%%  E-mail: yousef.abdi@gmail.com, y.abdi@tabrizu.ac.ir
%%%%%%%%%%%  November 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc;
clear;
clear all;
%% Problem Definition
for Problem=[1 2 3 4 6]
    global Settings;
    %CostFunction=@(x) ZDT4(x);  %Cost Function
    prob=num2str(Problem);
    CostFunction=str2func(['@(x)  ZDT' prob '(x)']);  %Cost Function
    load(['Problem_PFs\ZDT' prob '.mat']);
    %load(['..\Problem_PFs\ZDT' prob ]);
    %problemName=['DTLZ' prob '_2'];
    problemName=['ZDT' prob];
    
    switch Problem
        case num2cell([1 2 3])
            nVar=30;            
            VarMin(1:nVar)=0;
            VarMax(1:nVar)=1;
        case 4
            nVar=10;
            VarMin(1:nVar)=0;
            VarMax(1:nVar)=1;
            VarMin(2:nVar)=-5;
            VarMax(2:nVar)=5;
        case 6
            nVar=10;
            VarMin(1:nVar)=0;
            VarMax(1:nVar)=1;          
    end
    
    nRep=100;
    Settings.nRep= nRep;
    Settings.nVar= nVar;
    Settings.CostFunction=CostFunction;

    VarSize=[1 nVar];

    

    VarRange=[VarMin VarMax];
    Rep=[];
    PrevRep=[];    
    %% Parameters

    MaxIt=2000;

    nPop=5;

    pCrossover=0.9;
    nCrossover=round(pCrossover*nPop/2)*2;

    pMutation=0.1;
    nMutation=ceil(pMutation*nPop);

    mu=0.1;

    TotalRun=30;
    %% Initialization
    empty_individual.Position=[];
    empty_individual.Cost=[];
    empty_individual.Rank=[];
    empty_individual.CrowdingDistance=[];
    empty_individual.DominatedCount=[];
    empty_individual.DominationSet=[];
    empty_individual.IsDominated=false;

    pop=repmat(empty_individual,nPop,1);

    IGDs=zeros(MaxIt, TotalRun);
    HVs=zeros(MaxIt, TotalRun);

    for run=1:30

        for i=1:nPop
            pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
            pop(i).Cost=CostFunction(pop(i).Position);
            pop(i).IsDominated=false;
            pop(i).DominatedCount=0;
            pop(i).DominationSet=[];
            pop(i).Rank=[];
        end
        Rep=[];
        PrevRep=[];
        flag=0;
        %% NSGA-II Loop
        for it=1:MaxIt
            % Non-dominated Sorting
            [pop F]=NonDominatedSorting(pop);
            pop=CalcCrowdingDistance2(pop,F);
            Rep = MakeRepository(pop, Rep, F{1}, nRep);
            % Calculate Crowding Distances
            Rep=CalcCrowdingDistance(Rep);
            PrevRep=Rep;

            % Crossover
            popc=repmat(empty_individual,nCrossover/2,2);
            for k=1:nCrossover/2

                %i1=BinaryTournamentSelection(pop);
                %i2=BinaryTournamentSelection(pop);

                i=randi([1 numel(pop)],1,2);
                i1=i(1); i2=i(2);
                [popc(k,1).Position popc(k,2).Position]=Crossover(pop(i1).Position,pop(i2).Position,VarMin, VarMax, nVar);

                popc(k,1).Cost=CostFunction(popc(k,1).Position);
                popc(k,2).Cost=CostFunction(popc(k,2).Position);

            end
            popc=popc(:);

            % Mutation
            popm=repmat(empty_individual,nMutation,1);
            for k=1:nMutation

                i=randi([1 numel(pop)],1,1);

                popm(k).Position=Mutate(pop(i).Position,nVar,VarMin, VarMax);

                popm(k).Cost=CostFunction(popm(k).Position);

            end

            % Merge Pops
            pop=[pop
                 popc
                 popm];

            % Non-dominated Sorting
            [pop F]=NonDominatedSorting(pop);

            % Calculate Crowding Distances
            pop=CalcCrowdingDistance2(pop,F);

            % Sort Population
            pop=SortPopulation(pop);

            % Delete Extra Individuals

            pop=pop(1:nPop);

            % Non-dominated Sorting
            [pop F]=NonDominatedSorting(pop);

            % Calculate Crowding Distances
            pop=CalcCrowdingDistance2(pop, F);

            Rep = MakeRepository(pop, Rep, F{1}, nRep);
            Rep=CalcCrowdingDistance(Rep);

            % Check the Similarity between Rep and PrevRep
            Gotflg=SimilarityCheck(Rep, PrevRep);
            flag=flag+Gotflg;
            if flag>=5
                flag = 0;
                if numel(Rep)>1
                    Rep=ExploratoryOperator(Rep, VarMin,VarMax); 
                end
                for i=1:nPop
                    pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
                    pop(i).Cost=CostFunction(pop(i).Position);
                    pop(i).IsDominated=false;
                    pop(i).DominatedCount=0;
                    pop(i).DominationSet=[];
                    pop(i).Rank=[];
                end
            end

            WholeSolutions=[Rep
                            pop];
            xperm=randperm(numel(WholeSolutions));
            pop=WholeSolutions(xperm(1:nPop));
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            PrevRep=Rep;

            IGDs(it,run)=IGD([Rep.Cost]',PF);
            HVs(it,run)=HV([Rep.Cost]',PF);
            % Plot F1
            figure(1);
            PlotCosts2([Rep.Cost]);
            pause(0.0001);    

            % Show Iteration Information
            disp(['Problem= ' num2str(Problem) ' : Run= ' num2str(run) ' : Iteraion ' num2str(it) ': Number of F1 Members = ' num2str(numel(Rep))]);

        end
        Rep_Whole{run}=Rep;
        save(['D://MOGA_' problemName '_10000NFE.mat'],'HVs','IGDs', 'Rep', 'Rep_Whole');
    end
    
end
