function Rep = ExploratoryOperator( Rep, VarMin,VarMax )
    global Settings;
    
    CostFunction=Settings.CostFunction;
    
    temp_pos=zeros(numel(Rep),Settings.nVar);
    for i=1:numel(Rep)
       temp_pos(i,:)=Rep(i).Position; 
    end
    
    E1.Position=[];
    E1.Cost=[];
    E1.Rank=[];
    E1.CrowdingDistance=[];
    E1.DominatedCount=[];
    E1.DominationSet=[];
    E1.IsDominated=[];
    
    E2=E1;
    
    Xmin=min(temp_pos); Xmax=max(temp_pos);
    alpha=mean(temp_pos)./Xmax;
    
    E1.Position=Xmin+alpha.*(Xmax-Xmin);
    E2.Position=Xmin+(1-alpha).*(Xmax-Xmin);
    
    E1.Position=min(max(E1.Position,VarMin),VarMax);
    E2.Position=min(max(E2.Position,VarMin),VarMax);
    
    E1.Cost=CostFunction(E1.Position);
    E2.Cost=CostFunction(E2.Position);
    
    Rep=[Rep
        E1
        E2];
    
end

