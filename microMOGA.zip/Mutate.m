
function y=Mutate(x,nVar,VarMin,VarMax)

%% Gaussian Mutation
%     sigma=0.1*(VarMax-VarMin);
%     xnew=x+sigma.*randn(size(x));
%     xnew=min(max(xnew,VarMin),VarMax);
% 	
%     n=numel(x);
%     m=ceil(mu*n);
%     jj=randsample(n,m);
%     
%     y=x;
%     y(jj)=xnew(jj);
%     y = max(y, VarMin);
%     y = min(y, VarMax);

%% Polynomial Mutation
      [proM,disM] = deal(1,20);
      Site  = rand(1,nVar) < proM/nVar;
      mu    = rand(1,nVar);
      temp  = Site & mu<=1;
      Offspring=x;
      Offspring(temp) = Offspring(temp)+(VarMax(temp)-VarMin(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                          (1-(Offspring(temp)-VarMin(temp))./(VarMax(temp)-VarMin(temp))).^(disM+1)).^(1/(disM+1))-1);
      temp = Site & mu>0.5; 
      Offspring(temp) = Offspring(temp)+(VarMax(temp)-VarMin(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                          (1-(VarMax(temp)-Offspring(temp))./(VarMax(temp)-VarMin(temp))).^(disM+1)).^(1/(disM+1)));

      y = min(max(Offspring,VarMin),VarMax);  
                  
end